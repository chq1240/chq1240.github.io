#include<iostream>
using namespace std;
int n;
int A[100001],T[100001];

long long inverse_num = 0;

void merge_sort(int *A, int x, int y, int* T)
{
    if (y-x > 1)
    {
        int m = x + (y-x) / 2; 
        int p = x, q = m, i = x;
        merge_sort(A, x, m, T); 
        merge_sort(A, m, y, T); 
        while (p < m || q < y)
        {
            if(q >= y || (p < m && A[p] <= A[q]))
                T[i++] = A[p++];
            else 
            {
                T[i++] = A[q++];
                inverse_num += m-p;
            }
        }
        for(i=x; i<y; i++) 
        A[i] = T[i];
    }
}
int main()
{
    while(cin >> n)
    {
        inverse_num = 0;
        for(int i = 0;i<n;i++)
        {
            cin >> A[i];
        }
        merge_sort(A, 0, n, T);
        cout << inverse_num << endl;
    }
}    
