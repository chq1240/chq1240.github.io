
struct linkedlist{
    int data;
    linkedlist *next;
};

void mergesort(linkedlist *&head, int len)
{
    if(len == 1) return;
    
    int m = len / 2;
    linkedlist *mid = head; 
    linkedlist *rear = head, *new_head = NULL;
    
    for(int i = 0; i < m ; i++)
    {
        mid = mid->next;
        if(i == m - 2) 
        rear = mid;
    }
    
    rear->next = NULL;
    
    mergesort(head, m);
    mergesort(mid, len - m);
    
    linkedlist *temp1 = head, *temp2 = mid;
    linkedlist *new_rear = NULL;
    
    while(temp1 != NULL || temp2 != NULL)
    {
        if(temp2 == NULL ||(temp1 != NULL && temp1->data <= temp2->data))
        {
            if(new_head == NULL)
                new_head = temp1;
            else 
                new_rear->next = temp1;
                
            new_rear = temp1;
            temp1 = temp1->next;   
        }
        else 
        {
            if(new_head == NULL)
                new_head = temp2;
            else 
                new_rear->next = temp2;
            new_rear = temp2;
            temp2 = temp2->next;
        }
    }
    head = new_head;
}                                 
